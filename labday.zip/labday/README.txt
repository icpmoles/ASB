copy "helpers" folder from root if not present
run "prepare_environment.m"