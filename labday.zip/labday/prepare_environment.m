addpath(pwd+"\helpers")
cnc_params
FrequencyDesign
LQG_Design
PolePlacement