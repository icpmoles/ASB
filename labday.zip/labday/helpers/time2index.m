function idx = time2index(time)
idx = floor(time/0.002)+1;
end