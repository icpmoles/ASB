/*
 * Position_control_PP_LQ_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Position_control_PP_LQ".
 *
 * Model version              : 1.400
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May  9 12:53:24 2025
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Position_control_PP_LQ.h"
#include "Position_control_PP_LQ_private.h"

/* Block parameters (default storage) */
P_Position_control_PP_LQ_T Position_control_PP_LQ_P = {
  /* Variable: K0_lq
   * Referenced by: '<S3>/Gain2'
   */
  { -169.25687506432706, -26.216111700133197 },

  /* Variable: K1_lq
   * Referenced by: '<S4>/Gain2'
   */
  { -169.25687506432709, -26.230111983791573 },

  /* Mask Parameter: Plant_HighSat
   * Referenced by:
   *   '<S5>/10V sat0'
   *   '<S5>/10V sat1'
   */
  0.33,

  /* Mask Parameter: Plant_LowSat
   * Referenced by:
   *   '<S5>/low sat0'
   *   '<S5>/low sat1'
   */
  10.0,

  /* Mask Parameter: Plant_bias
   * Referenced by: '<S5>/bias enable'
   */
  0.0,

  /* Mask Parameter: Encoders_clock
   * Referenced by: '<S5>/Encoders'
   */
  0,

  /* Mask Parameter: Encoders_channels
   * Referenced by: '<S5>/Encoders'
   */
  { 0U, 1U },

  /* Mask Parameter: MotorsCommands_channels
   * Referenced by: '<S5>/Motors Commands'
   */
  { 0U, 1U },

  /* Mask Parameter: Encoders_samples_in_buffer
   * Referenced by: '<S5>/Encoders'
   */
  500U,

  /* Expression: 1
   * Referenced by: '<Root>/Gain'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<Root>/Gain1'
   */
  1.0,

  /* Expression: pi/180
   * Referenced by: '<S2>/Gain1'
   */
  0.017453292519943295,

  /* Expression: 7
   * Referenced by: '<Root>/Bias'
   */
  7.0,

  /* Expression: pi/180
   * Referenced by: '<S1>/Gain1'
   */
  0.017453292519943295,

  /* Expression: 10
   * Referenced by: '<S3>/Saturation'
   */
  10.0,

  /* Expression: -10
   * Referenced by: '<S3>/Saturation'
   */
  -10.0,

  /* Expression: 0.5
   * Referenced by: '<S5>/monitor sat 1 '
   */
  0.5,

  /* Expression: 0.5
   * Referenced by: '<S5>/monitor sat 0'
   */
  0.5,

  /* Expression: set_other_outputs_at_terminate
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: set_other_outputs_at_switch_out
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: set_other_outputs_at_start
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: set_other_outputs_at_switch_in
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: final_analog_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: final_pwm_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: analog_input_maximums
   * Referenced by: '<Root>/HIL Initialize'
   */
  10.0,

  /* Expression: analog_input_minimums
   * Referenced by: '<Root>/HIL Initialize'
   */
  -10.0,

  /* Expression: analog_output_maximums
   * Referenced by: '<Root>/HIL Initialize'
   */
  10.0,

  /* Expression: analog_output_minimums
   * Referenced by: '<Root>/HIL Initialize'
   */
  -10.0,

  /* Expression: initial_analog_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: watchdog_analog_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: pwm_frequency
   * Referenced by: '<Root>/HIL Initialize'
   */
  50.0,

  /* Expression: initial_pwm_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: watchdog_pwm_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: pi/2048
   * Referenced by: '<S5>/enc to rad0'
   */
  0.0015339807878856412,

  /* Expression: 20
   * Referenced by: '<Root>/Angle_amplitude_deg'
   */
  20.0,

  /* Expression: 1/(2*pi)
   * Referenced by: '<S8>/rads to hz'
   */
  0.15915494309189535,

  /* Expression: initial_phase
   * Referenced by: '<S8>/Smooth Signal Generator'
   */
  0.0,

  /* Expression: i_amplitude
   * Referenced by: '<S8>/Smooth Signal Generator'
   */
  1.0,

  /* Expression: i_frequency
   * Referenced by: '<S8>/Smooth Signal Generator'
   */
  1.0,

  /* Expression: pi/2048
   * Referenced by: '<S5>/enc to rad1'
   */
  0.0015339807878856412,

  /* Expression: 180/pi
   * Referenced by: '<S39>/Gain'
   */
  57.295779513082323,

  /* Expression: [  A0max A0min A0max+A0slack A0min-A1slack]
   * Referenced by: '<S5>/Constant4'
   */
  { 31.0, -17.0, 32.0, -18.0 },

  /* Expression: pi/180
   * Referenced by: '<S36>/Gain1'
   */
  0.017453292519943295,

  /* Expression: [  A1max A1min A1max+A1slack A1min-A1slack]
   * Referenced by: '<S5>/Constant3'
   */
  { 27.0, -27.0, 28.0, -28.0 },

  /* Expression: pi/180
   * Referenced by: '<S35>/Gain1'
   */
  0.017453292519943295,

  /* Computed Parameter: Internal_A
   * Referenced by: '<S13>/Internal'
   */
  { -245.07817785144158, 1.0, -18192.206280749913, -24.9218, -33.486688856280423,
    21769.837792850758 },

  /* Computed Parameter: Internal_B
   * Referenced by: '<S13>/Internal'
   */
  { 245.07817785144158, -33.486688856280423, 18192.206280749913,
    -21769.837792850758 },

  /* Computed Parameter: Internal_C
   * Referenced by: '<S13>/Internal'
   */
  { 1.0, 1.0, 1.0 },

  /* Computed Parameter: Internal_A_p
   * Referenced by: '<S14>/Internal'
   */
  { -37.960053786062765, 1.0, -720.48284172038632, -24.9218, -33.486688856280423,
    659.438478303843 },

  /* Computed Parameter: Internal_B_b
   * Referenced by: '<S14>/Internal'
   */
  { 37.960053786062765, -33.486688856280423, 720.48284172038632,
    -659.438478303843 },

  /* Computed Parameter: Internal_C_n
   * Referenced by: '<S14>/Internal'
   */
  { 1.0, 1.0, 1.0 },

  /* Computed Parameter: Internal_A_n
   * Referenced by: '<S20>/Internal'
   */
  -40.0,

  /* Computed Parameter: Internal_B_k
   * Referenced by: '<S20>/Internal'
   */
  32.0,

  /* Computed Parameter: Internal_C_i
   * Referenced by: '<S20>/Internal'
   */
  -50.0,

  /* Computed Parameter: Internal_D
   * Referenced by: '<S20>/Internal'
   */
  40.0,

  /* Expression: 0.0
   * Referenced by: '<S20>/Internal'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<Root>/1v'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<Root>/1v'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<Root>/1v'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<Root>/V_amplitude'
   */
  1.0,

  /* Expression: 1/(2*pi)
   * Referenced by: '<S7>/rads to hz'
   */
  0.15915494309189535,

  /* Expression: initial_phase
   * Referenced by: '<S7>/Smooth Signal Generator'
   */
  0.0,

  /* Expression: i_amplitude
   * Referenced by: '<S7>/Smooth Signal Generator'
   */
  1.0,

  /* Expression: i_frequency
   * Referenced by: '<S7>/Smooth Signal Generator'
   */
  1.0,

  /* Computed Parameter: Internal_A_a
   * Referenced by: '<S24>/Internal'
   */
  { -245.5602164382797, 1.0, -18298.559981149083, -24.4398, -33.486688856280423,
    21769.847125700227 },

  /* Computed Parameter: Internal_B_o
   * Referenced by: '<S24>/Internal'
   */
  { 245.5602164382797, -33.486688856280423, 18298.559981149083,
    -21769.847125700227 },

  /* Computed Parameter: Internal_C_o
   * Referenced by: '<S24>/Internal'
   */
  { 1.0, 1.0, 1.0 },

  /* Computed Parameter: Internal_A_m
   * Referenced by: '<S25>/Internal'
   */
  { -38.201719626065014, 1.0, -729.68569119423773, -24.4398, -33.486688856280423,
    659.43847830384209 },

  /* Computed Parameter: Internal_B_f
   * Referenced by: '<S25>/Internal'
   */
  { 38.201719626065014, -33.486688856280423, 729.68569119423773,
    -659.43847830384209 },

  /* Computed Parameter: Internal_C_f
   * Referenced by: '<S25>/Internal'
   */
  { 1.0, 1.0, 1.0 },

  /* Computed Parameter: Internal_A_o
   * Referenced by: '<S31>/Internal'
   */
  -40.0,

  /* Computed Parameter: Internal_B_e
   * Referenced by: '<S31>/Internal'
   */
  32.0,

  /* Computed Parameter: Internal_C_oc
   * Referenced by: '<S31>/Internal'
   */
  -50.0,

  /* Computed Parameter: Internal_D_a
   * Referenced by: '<S31>/Internal'
   */
  40.0,

  /* Expression: 0.0
   * Referenced by: '<S31>/Internal'
   */
  0.0,

  /* Expression: 0.5
   * Referenced by: '<Root>/Sine Wave3'
   */
  0.5,

  /* Expression: 0
   * Referenced by: '<Root>/Sine Wave3'
   */
  0.0,

  /* Expression: 5
   * Referenced by: '<Root>/Sine Wave3'
   */
  5.0,

  /* Expression: 0
   * Referenced by: '<Root>/Sine Wave3'
   */
  0.0,

  /* Expression: 10
   * Referenced by: '<S4>/Saturation'
   */
  10.0,

  /* Expression: -10
   * Referenced by: '<S4>/Saturation'
   */
  -10.0,

  /* Expression: 2
   * Referenced by: '<S5>/latch error'
   */
  2.0,

  /* Expression: -1
   * Referenced by: '<S5>/latch error'
   */
  -1.0,

  /* Expression: 1
   * Referenced by: '<S5>/latch error'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S5>/latch error'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S5>/monitor stop 0'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<S5>/monitor stop 1'
   */
  1.0,

  /* Expression: 0.0
   * Referenced by: '<S5>/1 sec delay'
   */
  0.0,

  /* Computed Parameter: HILInitialize_CKChannels
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOWatchdog
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_EIInitial
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POModes
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AIChannels
   * Referenced by: '<Root>/HIL Initialize'
   */
  { 0U, 1U },

  /* Computed Parameter: HILInitialize_AOChannels
   * Referenced by: '<Root>/HIL Initialize'
   */
  { 0U, 1U },

  /* Computed Parameter: HILInitialize_EIChannels
   * Referenced by: '<Root>/HIL Initialize'
   */
  { 0U, 1U },

  /* Computed Parameter: HILInitialize_EIQuadrature
   * Referenced by: '<Root>/HIL Initialize'
   */
  4U,

  /* Computed Parameter: ToHostFile_Decimation
   * Referenced by: '<Root>/To Host File'
   */
  1U,

  /* Computed Parameter: ToHostFile_BitRate
   * Referenced by: '<Root>/To Host File'
   */
  2000000U,

  /* Computed Parameter: HILInitialize_Active
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOTerminate
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_AOExit
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOTerminate
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOExit
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POTerminate
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_POExit
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AIPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_AIPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_AOPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_AOEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOReset
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOReset
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_EIPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_EIPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_EIStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_EIEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_POPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_POEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POReset
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_OOReset
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOFinal
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOInitial
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: Encoders_Active
   * Referenced by: '<S5>/Encoders'
   */
  1,

  /* Computed Parameter: MotorsCommands_Active
   * Referenced by: '<S5>/Motors Commands'
   */
  0,

  /* Computed Parameter: ManualSwitch5_CurrentSetting
   * Referenced by: '<Root>/Manual Switch5'
   */
  0U,

  /* Computed Parameter: ManualSwitch2_CurrentSetting
   * Referenced by: '<S3>/Manual Switch2'
   */
  0U,

  /* Computed Parameter: ManualSwitch2_CurrentSetting_p
   * Referenced by: '<S4>/Manual Switch2'
   */
  0U,

  /* Computed Parameter: ManualSwitch4_CurrentSetting
   * Referenced by: '<Root>/Manual Switch4'
   */
  1U,

  /* Computed Parameter: ManualSwitch_CurrentSetting
   * Referenced by: '<Root>/Manual Switch'
   */
  1U,

  /* Computed Parameter: ManualSwitch1_CurrentSetting
   * Referenced by: '<Root>/Manual Switch1'
   */
  0U,

  /* Computed Parameter: ManualSwitch1_CurrentSetting_m
   * Referenced by: '<S3>/Manual Switch1'
   */
  1U,

  /* Computed Parameter: ManualSwitch6_CurrentSetting
   * Referenced by: '<Root>/Manual Switch6'
   */
  0U,

  /* Computed Parameter: ManualSwitch2_CurrentSetting_i
   * Referenced by: '<Root>/Manual Switch2'
   */
  0U,

  /* Computed Parameter: ManualSwitch1_CurrentSetting_c
   * Referenced by: '<S4>/Manual Switch1'
   */
  1U,

  /* Computed Parameter: ManualSwitch3_CurrentSetting
   * Referenced by: '<Root>/Manual Switch3'
   */
  0U,

  /* Expression: file_name_argument
   * Referenced by: '<Root>/To Host File'
   */
  { 80U, 111U, 115U, 105U, 116U, 105U, 111U, 110U, 95U, 99U, 111U, 110U, 116U,
    114U, 111U, 108U, 95U, 80U, 80U, 95U, 76U, 81U, 95U, 48U, 57U, 45U, 77U, 97U,
    121U, 45U, 50U, 48U, 50U, 53U, 95U, 49U, 50U, 45U, 53U, 51U, 45U, 50U, 49U,
    46U, 109U, 97U, 116U, 0U },

  /* Expression: variable_name_argument
   * Referenced by: '<Root>/To Host File'
   */
  { 100U, 97U, 116U, 97U, 0U },

  /* Computed Parameter: ToHostFile_FileFormat
   * Referenced by: '<Root>/To Host File'
   */
  1U,

  /* Computed Parameter: ManualSwitch_CurrentSetting_p
   * Referenced by: '<S3>/Manual Switch'
   */
  1U,

  /* Computed Parameter: ManualSwitch_CurrentSetting_j
   * Referenced by: '<S4>/Manual Switch'
   */
  0U
};
